import React, { useState, useEffect } from 'react';
import { ArrowRight } from 'lucide-react';
import ProcessCard from '../components/ui/ProcessCard';
import VideoPlayer from '../components/ui/VideoPlayer';
import { processSteps } from '../data/process';

export default function ProcessPage() {
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };

    checkMobile();
    window.addEventListener('resize', checkMobile);

    return () => {
      window.removeEventListener('resize', checkMobile);
    };
  }, []);

  return (
    <div>
      {/* Hero Section */}
      <section className="pt-32 pb-20 bg-gradient-to-br from-blue-50 to-gray-100 dark:from-gray-900 dark:to-gray-800">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-6">
              Our Process
            </h1>
            <p className="text-xl text-gray-700 dark:text-gray-300">
              We follow a streamlined approach to deliver high-quality automation solutions quickly and efficiently.
            </p>
          </div>
        </div>
      </section>

      {/* Video Section */}
      <section className="py-20 bg-white dark:bg-gray-900">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-8 text-center">
              See Our Process in Action
            </h2>
            <VideoPlayer isMobile={isMobile} />
          </div>
        </div>
      </section>

      {/* Process Timeline Section */}
      <section className="py-20 bg-gray-50 dark:bg-gray-800">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-3xl mx-auto">
            {processSteps.map((step, index) => (
              <ProcessCard 
                key={step.id} 
                step={step} 
                index={index} 
                isLast={index === processSteps.length - 1}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Why Our Process Works */}
      <section className="py-20 bg-white dark:bg-gray-900">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-8 text-center">
              Why Our Process Works
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-gray-50 dark:bg-gray-800 p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3">Client-Focused Approach</h3>
                <p className="text-gray-700 dark:text-gray-300">
                  We begin by understanding your specific needs and goals, ensuring our solutions are perfectly tailored to your business requirements.
                </p>
              </div>

              <div className="bg-gray-50 dark:bg-gray-800 p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3">Rapid Iterations</h3>
                <p className="text-gray-700 dark:text-gray-300">
                  Our development process includes regular check-ins and quick iterations, allowing for feedback and adjustments throughout the project.
                </p>
              </div>

              <div className="bg-gray-50 dark:bg-gray-800 p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3">Efficient Delivery</h3>
                <p className="text-gray-700 dark:text-gray-300">
                  We prioritize speed without compromising quality, delivering functional solutions in a fraction of the time typically required.
                </p>
              </div>

              <div className="bg-gray-50 dark:bg-gray-800 p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3">Ongoing Support</h3>
                <p className="text-gray-700 dark:text-gray-300">
                  After delivery, we provide training and support to ensure your team can fully utilize the automation solutions we've implemented.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Satisfaction Guarantee */}
      <section className="py-20 bg-blue-600 dark:bg-blue-800">
        <div className="container mx-auto px-4 md:px-6 text-center">
          <h2 className="text-3xl font-bold text-white mb-6">Satisfaction Guaranteed</h2>
          <p className="text-xl text-blue-100 dark:text-blue-200 mb-8 max-w-3xl mx-auto">
            We're confident in our process and the solutions we deliver. If you're not completely satisfied with our work, we'll make it right.
          </p>
          <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4 justify-center">
            <a 
              href="https://calendly.com/keifcorp-trw/garcia-legal-appointment"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-white text-blue-600 hover:bg-gray-100 px-8 py-3 rounded-lg font-medium transition-colors inline-block"
            >
              Book a Consultation <ArrowRight className="ml-2 h-5 w-5 inline-block" />
            </a>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-20 bg-white dark:bg-gray-900">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-8 text-center">
              Frequently Asked Questions
            </h2>

            <div className="space-y-6">
              <div className="bg-gray-50 dark:bg-gray-800 p-6 rounded-lg">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                  How long does the entire process take?
                </h3>
                <p className="text-gray-700 dark:text-gray-300">
                  Most projects can be completed within 1-2 weeks, depending on complexity and scope. During our initial consultation, we'll provide you with a specific timeline for your project.
                </p>
              </div>

              <div className="bg-gray-50 dark:bg-gray-800 p-6 rounded-lg">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                  What if I need changes after the solution is delivered?
                </h3>
                <p className="text-gray-700 dark:text-gray-300">
                  We include a round of revisions in our standard process. Beyond that, we offer flexible maintenance packages to handle ongoing updates and changes as your business evolves.
                </p>
              </div>

              <div className="bg-gray-50 dark:bg-gray-800 p-6 rounded-lg">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                  Do I need technical knowledge to use the automation solutions?
                </h3>
                <p className="text-gray-700 dark:text-gray-300">
                  No, our solutions are designed to be user-friendly. We provide comprehensive training and documentation to ensure your team can easily manage and use the automated systems.
                </p>
              </div>

              <div className="bg-gray-50 dark:bg-gray-800 p-6 rounded-lg">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                  How do we get started?
                </h3>
                <p className="text-gray-700 dark:text-gray-300">
                  Simply book a consultation call through our calendar, and we'll discuss your needs, explain our process in detail, and provide you with a tailored proposal for your business.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}