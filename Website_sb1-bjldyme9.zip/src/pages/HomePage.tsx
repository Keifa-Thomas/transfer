import React from 'react';
import { Link } from 'react-router-dom';
import { ChevronRight, Zap, CheckCircle, ArrowRight } from 'lucide-react';
import ServiceCard from '../components/ui/ServiceCard';
import TestimonialCard from '../components/ui/TestimonialCard';
import { SplineSceneBasic } from '../components/ui/demo';
import { services } from '../data/services';
import { testimonials } from '../data/testimonials';

export default function HomePage() {
  const featuredServices = services.slice(0, 3);
  const featuredTestimonials = testimonials.slice(0, 2);

  return (
    <div>
      <section className="pt-32 pb-20 bg-gradient-to-br from-blue-50 to-gray-100 dark:from-gray-900 dark:to-gray-800">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex flex-col lg:flex-row items-center">
            <div className="lg:w-1/2 lg:pr-12">
              <h1 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-6 leading-tight tracking-tight">
                Fast & Efficient <span className="text-blue-600 dark:text-blue-500">Automation</span> Solutions
              </h1>
              <p className="text-xl text-gray-700 dark:text-gray-300 mb-8">
                From website builds to intelligent bots, we provide quick solutions to improve business efficiency and reduce manual labor.
              </p>
              <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
                <Link 
                  to="/contact" 
                  className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-lg font-medium transition-colors flex items-center justify-center"
                >
                  Get Started <ChevronRight className="ml-2 h-5 w-5" />
                </Link>
                <Link 
                  to="/services" 
                  className="bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-700 text-gray-800 dark:text-gray-200 px-8 py-3 rounded-lg font-medium transition-colors flex items-center justify-center hover:bg-gray-100 dark:hover:bg-gray-700"
                >
                  Explore Services
                </Link>
              </div>
            </div>
            <div className="lg:w-1/2 mt-12 lg:mt-0">
              <SplineSceneBasic />
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white dark:bg-gray-900">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">Why Choose Us?</h2>
            <p className="text-xl text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
              We combine speed with quality to deliver exceptional automation solutions that transform your business.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-gray-50 dark:bg-gray-800 p-8 rounded-lg">
              <div className="bg-blue-100 dark:bg-blue-900 rounded-full w-14 h-14 flex items-center justify-center mb-6">
                <svg className="w-7 h-7 text-blue-600 dark:text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3">Rapid Development</h3>
              <p className="text-gray-600 dark:text-gray-400">
                We deliver high-quality automation solutions with industry-leading turnaround times so you can see results quickly.
              </p>
            </div>

            <div className="bg-gray-50 dark:bg-gray-800 p-8 rounded-lg">
              <div className="bg-blue-100 dark:bg-blue-900 rounded-full w-14 h-14 flex items-center justify-center mb-6">
                <svg className="w-7 h-7 text-blue-600 dark:text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3">Proven Reliability</h3>
              <p className="text-gray-600 dark:text-gray-400">
                Our solutions are built on proven frameworks and technologies, ensuring stability and long-term performance.
              </p>
            </div>

            <div className="bg-gray-50 dark:bg-gray-800 p-8 rounded-lg">
              <div className="bg-blue-100 dark:bg-blue-900 rounded-full w-14 h-14 flex items-center justify-center mb-6">
                <svg className="w-7 h-7 text-blue-600 dark:text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3">Cost Effective</h3>
              <p className="text-gray-600 dark:text-gray-400">
                Our automation solutions deliver significant ROI by reducing manual labor costs and improving operational efficiency.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Services Preview Section */}
      <section className="py-20 bg-gray-50 dark:bg-gray-800">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-16">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">Our Services</h2>
              <p className="text-xl text-gray-600 dark:text-gray-400 max-w-2xl">
                Streamline your business with our comprehensive automation solutions.
              </p>
            </div>
            <Link 
              to="/services" 
              className="mt-6 md:mt-0 text-blue-600 dark:text-blue-500 hover:text-blue-800 dark:hover:text-blue-400 font-medium flex items-center group"
            >
              View all services 
              <ArrowRight className="ml-2 h-5 w-5 transition-transform group-hover:translate-x-1" />
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredServices.map(service => (
              <ServiceCard key={service.id} service={service} />
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20 bg-blue-600 dark:bg-blue-800">
        <div className="container mx-auto px-4 md:px-6 text-center">
          <h2 className="text-3xl font-bold text-white mb-6">Ready to Automate Your Business?</h2>
          <p className="text-xl text-blue-100 dark:text-blue-200 mb-8 max-w-3xl mx-auto">
            Stop wasting time on repetitive tasks. Let our automation solutions handle the work while you focus on growing your business.
          </p>
          <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4 justify-center">
            <Link 
              to="/contact" 
              className="bg-white text-blue-600 hover:bg-gray-100 px-8 py-3 rounded-lg font-medium transition-colors inline-block"
            >
              Get Started
            </Link>
            <a 
              href="https://calendly.com/keifcorp-trw/garcia-legal-appointment"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-transparent border-2 border-white text-white hover:bg-white hover:text-blue-600 px-8 py-3 rounded-lg font-medium transition-colors inline-block"
            >
              Book a Consultation
            </a>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 bg-white dark:bg-gray-900">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">Client Success Stories</h2>
            <p className="text-xl text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
              See how our automation solutions have transformed businesses like yours.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {featuredTestimonials.map(testimonial => (
              <TestimonialCard key={testimonial.id} testimonial={testimonial} />
            ))}
          </div>

          <div className="mt-12 text-center">
            <Link 
              to="/contact" 
              className="text-blue-600 dark:text-blue-500 hover:text-blue-800 dark:hover:text-blue-400 font-medium inline-flex items-center"
            >
              Become our next success story <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
          </div>
        </div>
      </section>

      {/* Trust Signals */}
      <section className="py-16 bg-gray-50 dark:bg-gray-800">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-10">
            <h3 className="text-2xl font-semibold text-gray-900 dark:text-white">Trusted by Businesses</h3>
          </div>

          <div className="flex flex-wrap justify-center gap-12 opacity-70">
            {/* Placeholder for client logos - using generic brand names */}
            <div className="flex items-center">
              <span className="text-2xl font-bold text-gray-500 dark:text-gray-400">TechFirm</span>
            </div>
            <div className="flex items-center">
              <span className="text-2xl font-bold text-gray-500 dark:text-gray-400">GrowthCo</span>
            </div>
            <div className="flex items-center">
              <span className="text-2xl font-bold text-gray-500 dark:text-gray-400">InnovateLabs</span>
            </div>
            <div className="flex items-center">
              <span className="text-2xl font-bold text-gray-500 dark:text-gray-400">NextWave</span>
            </div>
            <div className="flex items-center">
              <span className="text-2xl font-bold text-gray-500 dark:text-gray-400">FutureSys</span>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}