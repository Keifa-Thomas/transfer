import React from 'react';
import { ArrowRight } from 'lucide-react';
import * as LucideIcons from 'lucide-react';
import { services } from '../data/services';

export default function ServicesPage() {
  return (
    <div>
      {/* Hero Section */}
      <section className="pt-32 pb-20 bg-gradient-to-br from-sky-50 to-white dark:from-gray-900 dark:to-gray-800">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-6">
              Our Automation Services
            </h1>
            <p className="text-xl text-gray-700 dark:text-gray-300">
              Discover our comprehensive range of automation solutions designed to streamline your business operations and boost efficiency.
            </p>
          </div>
        </div>
      </section>

      {/* Services Detail Section */}
      <section className="py-20 bg-white dark:bg-gray-900">
        <div className="container mx-auto px-4 md:px-6">
          {services.map((service, index) => {
            const IconComponent = LucideIcons[service.icon as keyof typeof LucideIcons];
            const isEven = index % 2 === 0;

            return (
              <div 
                key={service.id}
                id={service.id}
                className={`flex flex-col ${isEven ? 'lg:flex-row' : 'lg:flex-row-reverse'} items-center mb-20`}
              >
                <div className="lg:w-1/2 mb-10 lg:mb-0">
                  <div className={`relative ${isEven ? 'lg:pr-12' : 'lg:pl-12'}`}>
                    <div className="bg-gray-100 dark:bg-gray-800 rounded-lg overflow-hidden">
                      <img 
                        src={getServiceImage(service.id)}
                        alt={service.title}
                        className="w-full h-auto object-cover"
                      />
                    </div>
                    <div className="absolute -bottom-5 bg-white dark:bg-gray-800 rounded-lg shadow-lg p-4 flex items-center">
                      <div className="bg-sky-100 dark:bg-sky-900 p-3 rounded-full mr-4">
                        {IconComponent && (
                          <IconComponent className="h-6 w-6 text-sky-600 dark:text-sky-500" />
                        )}
                      </div>
                      <div>
                        <p className="font-bold text-gray-900 dark:text-white">{service.title}</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">{service.turnaround}</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="lg:w-1/2">
                  <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
                    {service.title}
                  </h2>
                  <p className="text-lg text-gray-700 dark:text-gray-300 mb-6">
                    {getServiceDetailedDescription(service.id)}
                  </p>
                  
                  <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3">
                    Key Benefits
                  </h3>
                  <ul className="space-y-3 mb-6">
                    {getServiceBenefits(service.id).map((benefit, idx) => (
                      <li key={idx} className="flex items-start">
                        <span className="text-sky-500 mr-2 mt-1">
                          <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd"></path>
                          </svg>
                        </span>
                        <span className="text-gray-700 dark:text-gray-300">{benefit}</span>
                      </li>
                    ))}
                  </ul>
                  
                  <div className="flex">
                    <a 
                      href="https://calendly.com/keifcorp-trw/garcia-legal-appointment"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="bg-sky-600 hover:bg-sky-700 text-white px-5 py-2 rounded-lg transition-colors flex items-center"
                    >
                      Book a Consultation <ArrowRight className="ml-2 h-5 w-5" />
                    </a>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20 bg-sky-50 dark:bg-gray-800">
        <div className="container mx-auto px-4 md:px-6 text-center">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-6">Ready to Transform Your Business?</h2>
          <p className="text-xl text-gray-600 dark:text-gray-400 mb-8 max-w-3xl mx-auto">
            Our automation solutions are designed to save you time, reduce costs, and boost your business efficiency.
          </p>
          <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4 justify-center">
            <a 
              href="https://calendly.com/keifcorp-trw/garcia-legal-appointment"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-sky-600 hover:bg-sky-700 text-white px-8 py-3 rounded-lg font-medium transition-colors inline-block"
            >
              Schedule a Free Consultation
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}

// Helper functions
function getServiceImage(serviceId: string): string {
  const serviceImages = {
    websites: "https://images.pexels.com/photos/1181467/pexels-photo-1181467.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    chatbots: "https://images.pexels.com/photos/8386440/pexels-photo-8386440.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    email: "https://images.pexels.com/photos/1591062/pexels-photo-1591062.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    voice: "https://images.freepik.com/free-photo/ai-robot-call-center-customer-service-with-headset_1142-36552.jpg",
  };
  
  return serviceImages[serviceId as keyof typeof serviceImages] || "https://images.pexels.com/photos/3183150/pexels-photo-3183150.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1";
}

function getServiceDetailedDescription(serviceId: string): string {
  const descriptions = {
    websites: "Our custom website development service focuses on creating modern, responsive websites that not only look great but also drive conversions. We design with both aesthetics and functionality in mind, ensuring your site works perfectly across all devices and provides an exceptional user experience.",
    chatbots: "Our AI-powered chatbots are designed to engage with your customers 24/7, answering questions, booking appointments, and providing information instantly. These intelligent assistants help reduce customer service workload while improving response times and customer satisfaction.",
    email: "Our automated email systems handle everything from customer onboarding and lead nurturing to appointment reminders and follow-ups. These sophisticated systems ensure timely, personalized communication with your clients, boosting engagement and conversion rates.",
    voice: "Our AI voice caller technology enables automated phone interactions that sound natural and human-like. These systems can handle inbound and outbound calls, schedule appointments, collect information, and provide excellent customer service without human intervention.",
  };
  
  return descriptions[serviceId as keyof typeof descriptions] || "";
}

function getServiceBenefits(serviceId: string): string[] {
  const benefits = {
    websites: [
      "Custom-designed to match your brand and business needs",
      "Fast loading and responsive design for all devices",
      "SEO-optimized structure for better search rankings",
      "Integrated with analytics to track performance",
      "1-2 weeks turnaround for most projects"
    ],
    chatbots: [
      "24/7 availability for instant customer support",
      "Seamless integration with your website and existing systems",
      "Continuous learning to improve responses over time",
      "Significant reduction in customer service costs",
      "Ability to handle multiple conversations simultaneously"
    ],
    email: [
      "Personalized email sequences based on customer behavior",
      "Automated follow-ups at the perfect timing",
      "Appointment reminders to reduce no-shows",
      "Detailed analytics on open rates and engagement",
      "Integration with your CRM and other business tools"
    ],
    voice: [
      "Natural-sounding voice interactions that feel human",
      "Ability to make outbound calls for confirmations and reminders",
      "Handle inbound calls for appointments and information",
      "Multilingual support for diverse customer bases",
      "Detailed call analytics and transcriptions"
    ],
  };
  
  return benefits[serviceId as keyof typeof benefits] || [];
}