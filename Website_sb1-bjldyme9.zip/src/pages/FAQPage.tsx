import React from 'react';
import { faqs } from '../data/faqs';

export default function FAQPage() {
  return (
    <div>
      {/* Hero Section */}
      <section className="pt-32 pb-20 bg-gradient-to-br from-blue-50 to-gray-100 dark:from-gray-900 dark:to-gray-800">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-6">
              Frequently Asked Questions
            </h1>
            <p className="text-xl text-gray-700 dark:text-gray-300">
              Find answers to common questions about our automation services and process.
            </p>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-white dark:bg-gray-900">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-3xl mx-auto">
            <div className="space-y-8">
              {faqs.map((faq) => (
                <div key={faq.id} className="bg-gray-50 dark:bg-gray-800 rounded-lg p-6">
                  <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3">
                    {faq.question}
                  </h3>
                  <p className="text-gray-700 dark:text-gray-300">
                    {faq.answer}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Chat Bot Demo Section */}
      <section className="py-20 bg-gray-50 dark:bg-gray-800">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-6">
              Try Our AI Assistant
            </h2>
            <p className="text-xl text-gray-700 dark:text-gray-300 mb-8">
              Our chatbot can answer many common questions instantly. Try it out by clicking the chat icon in the corner of this page.
            </p>
            <div className="bg-white dark:bg-gray-900 p-8 rounded-lg shadow-md">
              <p className="text-gray-700 dark:text-gray-300">
                This is a live demonstration of the same technology we can implement for your business. Ask questions about our services, process, or general automation inquiries!
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Still Have Questions */}
      <section className="py-20 bg-blue-600 dark:bg-blue-800">
        <div className="container mx-auto px-4 md:px-6 text-center">
          <h2 className="text-3xl font-bold text-white mb-6">Still Have Questions?</h2>
          <p className="text-xl text-blue-100 dark:text-blue-200 mb-8 max-w-3xl mx-auto">
            Our team is ready to help answer any questions you might have about our automation services.
          </p>
          <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4 justify-center">
            <a 
              href="https://calendly.com/keifcorp-trw/garcia-legal-appointment"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-white text-blue-600 hover:bg-gray-100 px-8 py-3 rounded-lg font-medium transition-colors inline-block"
            >
              Book a Consultation
            </a>
            <a 
              href="mailto:hello@speedautomation.com"
              className="bg-transparent border-2 border-white text-white hover:bg-white hover:text-blue-600 px-8 py-3 rounded-lg font-medium transition-colors inline-block"
            >
              Email Us
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}