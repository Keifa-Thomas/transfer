import React from 'react';

export default function TermsPage() {
  return (
    <div>
      {/* Hero Section */}
      <section className="pt-32 pb-20 bg-gradient-to-br from-blue-50 to-gray-100 dark:from-gray-900 dark:to-gray-800">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-6">
              Terms of Service
            </h1>
            <p className="text-xl text-gray-700 dark:text-gray-300">
              Last Updated: June 1, 2025
            </p>
          </div>
        </div>
      </section>

      {/* Content Section */}
      <section className="py-20 bg-white dark:bg-gray-900">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-3xl mx-auto prose dark:prose-invert">
            <h2>Introduction</h2>
            <p>
              These Terms of Service ("Terms") govern your use of the website and services offered by SpeedAutomation ("we," "our," or "us"). By accessing our website or using our services, you agree to be bound by these Terms.
            </p>
            
            <h2>Use of Services</h2>
            <p>
              Our services are designed to provide automation solutions for businesses. You may use our services only as permitted by these Terms and any applicable laws and regulations.
            </p>
            
            <h2>User Accounts</h2>
            <p>
              Some of our services require you to create an account. You are responsible for safeguarding your account information and for all activities that occur under your account. You agree to notify us immediately of any unauthorized use of your account.
            </p>
            
            <h2>Content and Intellectual Property</h2>
            <p>
              All content on our website, including text, graphics, logos, images, software, and other materials, is owned by or licensed to us and is protected by copyright, trademark, and other intellectual property laws. You may not copy, reproduce, distribute, modify, or create derivative works from any content without our explicit permission.
            </p>
            
            <h2>Client Obligations</h2>
            <p>
              When using our services, you agree to:
            </p>
            <ul>
              <li>Provide accurate and complete information</li>
              <li>Cooperate with our reasonable requests for information and assistance</li>
              <li>Ensure that your use of our services complies with all applicable laws and regulations</li>
              <li>Not use our services for any illegal or unauthorized purpose</li>
            </ul>
            
            <h2>Payment Terms</h2>
            <p>
              For paid services, you agree to pay all fees in accordance with the pricing and payment terms presented to you. All payments are non-refundable unless explicitly stated otherwise in a separate agreement.
            </p>
            
            <h2>Confidentiality</h2>
            <p>
              We respect the confidentiality of any proprietary information shared with us during the provision of our services. Similarly, you agree to maintain the confidentiality of any proprietary information we share with you.
            </p>
            
            <h2>Limitation of Liability</h2>
            <p>
              To the maximum extent permitted by law, we shall not be liable for any indirect, incidental, special, consequential, or punitive damages resulting from your use of or inability to use our services.
            </p>
            
            <h2>Warranty Disclaimer</h2>
            <p>
              Our services are provided "as is" and "as available" without warranties of any kind, either express or implied, including but not limited to warranties of merchantability, fitness for a particular purpose, or non-infringement.
            </p>
            
            <h2>Termination</h2>
            <p>
              We may terminate or suspend your access to our services immediately, without prior notice or liability, for any reason, including if you breach these Terms. Upon termination, your right to use our services will cease immediately.
            </p>
            
            <h2>Changes to Terms</h2>
            <p>
              We reserve the right to modify these Terms at any time. We will provide notice of significant changes by posting the updated Terms on our website and updating the "Last Updated" date.
            </p>
            
            <h2>Governing Law</h2>
            <p>
              These Terms shall be governed by and construed in accordance with the laws of the State of California, without regard to its conflict of law provisions.
            </p>
            
            <h2>Contact Us</h2>
            <p>
              If you have any questions about these Terms, please contact us at:
            </p>
            <p>
              Email: legal@speedautomation.com<br />
              Phone: +1 (555) 123-4567<br />
              Address: 123 Innovation Street, San Francisco, CA 94103
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}