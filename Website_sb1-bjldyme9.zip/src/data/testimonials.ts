import { Testimonial } from '../types';

export const testimonials: Testimonial[] = [
  {
    id: '1',
    name: 'Sarah Johnson',
    company: 'Apex Consulting',
    comment: 'The automation solutions provided have transformed our business workflows. We\'ve seen a 40% increase in efficiency and our clients are happier than ever.',
    image: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=600',
  },
  {
    id: '2',
    name: 'Michael Chen',
    company: 'TechForward',
    comment: 'The AI chatbot created for our website has reduced customer service inquiries by 65% while maintaining high satisfaction rates. Highly recommended!',
    image: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=600',
  },
  {
    id: '3',
    name: 'Jessica Miller',
    company: 'GrowthPoint',
    comment: 'Our email automation system has revolutionized our lead generation process. We\'re now converting 30% more leads with less manual effort.',
    image: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=600',
  },
];