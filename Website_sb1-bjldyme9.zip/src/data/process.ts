import { ProcessStep } from '../types';

export const processSteps: ProcessStep[] = [
  {
    id: '1',
    title: 'Consultation',
    description: 'We begin with a thorough consultation to understand your business needs, challenges, and goals for automation.',
    icon: 'Clipboard',
  },
  {
    id: '2',
    title: 'Design',
    description: 'Our team develops a custom design and strategy tailored to your specific requirements and business processes.',
    icon: 'Paintbrush',
  },
  {
    id: '3',
    title: 'Build',
    description: 'We efficiently build your automation solution with regular updates and opportunities for feedback.',
    icon: 'Code2',
  },
  {
    id: '4',
    title: 'Delivery',
    description: 'Once complete, we deploy your solution, provide training, and ensure everything works perfectly.',
    icon: 'Package',
  },
];