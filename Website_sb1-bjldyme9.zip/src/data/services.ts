import { Service } from '../types';

export const services: Service[] = [
  {
    id: 'websites',
    title: 'Website Creation',
    description: 'Custom websites built for your specific business needs with modern design and functionality.',
    icon: 'Globe',
    turnaround: '1-2 weeks',
  },
  {
    id: 'chatbots',
    title: 'AI-powered Chatbots',
    description: 'Intelligent chatbots that handle client interactions, appointment booking, and FAQs 24/7.',
    icon: 'MessageSquare',
    turnaround: '1 week',
  },
  {
    id: 'email',
    title: 'Email Automation',
    description: 'Automated email outreach systems for client acquisition, follow-ups, and appointment reminders.',
    icon: 'Mail',
    turnaround: '3-5 days',
  },
  {
    id: 'voice',
    title: 'AI Voice Callers',
    description: 'AI voice caller bots that handle phone-based interactions like reservations and appointment booking.',
    icon: 'Phone',
    turnaround: '1-2 weeks',
  },
];