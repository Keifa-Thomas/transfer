import { FAQ } from '../types';

export const faqs: FAQ[] = [
  {
    id: '1',
    question: 'How long does it typically take to build a custom website?',
    answer: 'Most websites can be completed within 1-2 weeks depending on complexity and requirements. We focus on efficient delivery without compromising quality.',
  },
  {
    id: '2',
    question: 'Can I integrate the chatbot with my existing systems?',
    answer: 'Yes, our AI chatbots are designed to integrate seamlessly with your existing CRM, booking systems, and other business tools to provide a unified experience.',
  },
  {
    id: '3',
    question: 'How do the AI voice callers work?',
    answer: 'Our AI voice callers use advanced natural language processing to handle phone interactions just like a human would. They can make outbound calls, answer incoming calls, book appointments, and more.',
  },
  {
    id: '4',
    question: 'Do you offer ongoing support after implementing automation solutions?',
    answer: 'Absolutely! We provide comprehensive support and maintenance packages to ensure your automation solutions continue to run smoothly and can be updated as your business evolves.',
  },
  {
    id: '5',
    question: 'What kind of ROI can I expect from these automation services?',
    answer: 'Clients typically see ROI within 3-6 months of implementation. This includes time savings, increased conversion rates, and improved customer satisfaction. We\'ll work with you to track and measure these metrics.',
  },
];