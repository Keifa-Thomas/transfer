import React from 'react';

export default function AnimatedBackground() {
  return (
    <div className="fixed inset-0 -z-10 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-sky-100 via-white to-sky-50">
        {/* Animated blobs - larger on desktop, smaller on mobile */}
        <div 
          className="absolute w-[800px] md:w-[1000px] h-[800px] md:h-[1000px] 
          bg-sky-500/30 rounded-full blur-[128px] md:blur-[196px] 
          animate-blob mix-blend-soft-light
          -top-[200px] -left-[200px]"
        ></div>
        <div 
          className="absolute w-[800px] md:w-[1000px] h-[800px] md:h-[1000px] 
          bg-sky-500/30 rounded-full blur-[128px] md:blur-[196px] 
          animate-blob animation-delay-2000 mix-blend-soft-light
          top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2"
        ></div>
        <div 
          className="absolute w-[800px] md:w-[1000px] h-[800px] md:h-[1000px] 
          bg-sky-500/30 rounded-full blur-[128px] md:blur-[196px] 
          animate-blob animation-delay-4000 mix-blend-soft-light
          -bottom-[200px] -right-[200px]"
        ></div>
        
        {/* Noise overlay with reduced opacity */}
        <div className="absolute inset-0 bg-noise opacity-30 mix-blend-soft-light"></div>
      </div>
    </div>
  );
}