import React from 'react';
import { Link } from 'react-router-dom';
import * as LucideIcons from 'lucide-react';
import { Service } from '../../types';

interface ServiceCardProps {
  service: Service;
}

export default function ServiceCard({ service }: ServiceCardProps) {
  // Dynamically get the icon component
  const IconComponent = LucideIcons[service.icon as keyof typeof LucideIcons];

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden transition-transform duration-300 hover:scale-[1.02] hover:shadow-lg">
      <div className="p-6">
        <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900 rounded-lg flex items-center justify-center mb-4">
          {IconComponent && (
            <IconComponent className="h-6 w-6 text-blue-600 dark:text-blue-500" />
          )}
        </div>
        
        <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
          {service.title}
        </h3>
        
        <p className="text-gray-600 dark:text-gray-400 mb-4">
          {service.description}
        </p>
        
        <div className="flex justify-between items-center">
          <span className="text-sm font-medium bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-400 py-1 px-2 rounded-full">
            {service.turnaround} turnaround
          </span>
          
          <Link 
            to={`/services#${service.id}`} 
            className="text-blue-600 dark:text-blue-500 font-medium hover:text-blue-700 dark:hover:text-blue-400 transition-colors"
          >
            Learn more
          </Link>
        </div>
      </div>
    </div>
  );
}