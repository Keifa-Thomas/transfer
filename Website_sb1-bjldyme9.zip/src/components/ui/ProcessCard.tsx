import React from 'react';
import * as LucideIcons from 'lucide-react';
import { ProcessStep } from '../../types';

interface ProcessCardProps {
  step: ProcessStep;
  index: number;
  isLast: boolean;
}

export default function ProcessCard({ step, index, isLast }: ProcessCardProps) {
  // Dynamically get the icon component
  const IconComponent = LucideIcons[step.icon as keyof typeof LucideIcons];

  return (
    <div className="relative">
      <div className="flex items-start">
        <div className="flex flex-col items-center mr-4">
          <div className="flex items-center justify-center w-10 h-10 rounded-full bg-blue-600 text-white font-bold">
            {index + 1}
          </div>
          {!isLast && (
            <div className="h-full w-0.5 bg-blue-200 dark:bg-blue-800 my-2"></div>
          )}
        </div>
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 flex-1 mb-6">
          <div className="flex items-center mb-3">
            {IconComponent && (
              <IconComponent className="h-5 w-5 text-blue-600 dark:text-blue-500 mr-2" />
            )}
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
              {step.title}
            </h3>
          </div>
          <p className="text-gray-600 dark:text-gray-400">
            {step.description}
          </p>
        </div>
      </div>
    </div>
  );
}