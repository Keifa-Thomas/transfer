import React, { useEffect, useState } from 'react';
import { MessageSquare } from 'lucide-react';

export default function ChatWidget() {
  const [isVisible, setIsVisible] = useState(false);
  const [hasInteracted, setHasInteracted] = useState(false);

  useEffect(() => {
    // Add Voiceflow chatbot script
    const script = document.createElement('script');
    script.type = 'text/javascript';
    script.innerHTML = `
      (function(d, t) {
        var v = d.createElement(t), s = d.getElementsByTagName(t)[0];
        v.onload = function() {
          window.voiceflow.chat.load({
            verify: { projectID: '67b7ebecf2a0a0c3b286b08c' },
            url: 'https://general-runtime.voiceflow.com',
            versionID: 'production',
            voice: {
              url: "https://runtime-api.voiceflow.com"
            }
          });
        }
        v.src = "https://cdn.voiceflow.com/widget-next/bundle.mjs"; v.type = "text/javascript"; s.parentNode.insertBefore(v, s);
      })(document, 'script');
    `;
    document.body.appendChild(script);

    // Show tooltip after 3 seconds if user hasn't interacted
    const timer = setTimeout(() => {
      if (!hasInteracted) {
        setIsVisible(true);
      }
    }, 3000);

    return () => {
      clearTimeout(timer);
      document.body.removeChild(script);
    };
  }, [hasInteracted]);

  const handleClick = () => {
    setIsVisible(false);
    setHasInteracted(true);
  };

  return (
    <div 
      className="fixed bottom-24 right-6 z-50"
      onClick={handleClick}
    >
      {isVisible && (
        <div className="absolute bottom-full right-0 mb-4 bg-white dark:bg-gray-800 p-4 rounded-lg shadow-lg w-64 animate-bounce">
          <p className="text-sm text-gray-700 dark:text-gray-300">
            👋 Hi! I'm your AI Assistant. How can I help you today?
          </p>
          <div className="absolute bottom-0 right-4 transform translate-y-1/2 rotate-45 w-4 h-4 bg-white dark:bg-gray-800"></div>
        </div>
      )}
    </div>
  );
}