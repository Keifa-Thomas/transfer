import React, { useState } from 'react';

export default function SplineScene() {
  const [isLoading, setIsLoading] = useState(true);
  const [hasError, setHasError] = useState(false);

  const handleLoad = () => {
    setIsLoading(false);
  };

  const handleError = () => {
    setIsLoading(false);
    setHasError(true);
  };

  return (
    <div className="spline-container w-full h-full min-h-[600px] relative">
      {isLoading && (
        <div className="absolute inset-0 flex items-center justify-center bg-gray-50 dark:bg-gray-800">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-600"></div>
        </div>
      )}
      {hasError && (
        <div className="absolute inset-0 flex items-center justify-center bg-gray-50 dark:bg-gray-800">
          <p className="text-red-600 dark:text-red-400">Failed to load 3D scene. Please refresh the page.</p>
        </div>
      )}
      <iframe 
        src='https://my.spline.design/interactiveaiwebsite-M7C5gqHLhy2H0Ivfmb7Dv3Xe/'
        frameBorder='0'
        width='100%'
        height='100%'
        className="absolute inset-0"
        onLoad={handleLoad}
        onError={handleError}
        title="Interactive 3D Scene"
      />
    </div>
  );
}