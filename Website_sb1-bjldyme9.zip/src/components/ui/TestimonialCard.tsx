import React from 'react';
import { Testimonial } from '../../types';

interface TestimonialCardProps {
  testimonial: Testimonial;
}

export default function TestimonialCard({ testimonial }: TestimonialCardProps) {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
      <div className="flex items-start space-x-4">
        <img 
          src={testimonial.image} 
          alt={testimonial.name}
          className="w-12 h-12 rounded-full object-cover"
        />
        <div>
          <p className="text-gray-700 dark:text-gray-300 mb-4">"{testimonial.comment}"</p>
          <div>
            <h4 className="font-medium text-gray-900 dark:text-white">{testimonial.name}</h4>
            <p className="text-gray-600 dark:text-gray-400 text-sm">{testimonial.company}</p>
          </div>
        </div>
      </div>
    </div>
  );
}