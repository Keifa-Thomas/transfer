import React from 'react';

interface VideoPlayerProps {
  isMobile: boolean;
}

export default function VideoPlayer({ isMobile }: VideoPlayerProps) {
  const videoUrl = isMobile 
    ? 'https://www.youtube.com/embed/eNrJ3s6Gw4k'
    : 'https://www.youtube.com/embed/2MRtAaSGXD4';

  return (
    <div className="relative w-full aspect-video rounded-lg overflow-hidden shadow-lg bg-gray-100 dark:bg-gray-800">
      <iframe 
        width="100%" 
        height="100%" 
        src={videoUrl}
        title="YouTube video player" 
        frameBorder="0" 
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" 
        allowFullScreen
        className="absolute inset-0"
      />
    </div>
  );
}