import React from 'react';
import { Link } from 'react-router-dom';
import { Facebook, Twitter, Instagram, Linkedin, Zap } from 'lucide-react';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-gray-100 dark:bg-gray-900 pt-16 pb-8">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand */}
          <div>
            <Link to="/" className="flex items-center space-x-2 mb-4">
              <Zap className="h-7 w-7 text-blue-600 dark:text-blue-500" />
              <span className="text-lg font-bold text-gray-900 dark:text-white tracking-tight">K.CORP</span>
            </Link>
            <p className="text-gray-600 dark:text-gray-400 mb-6">
              Fast and efficient automation services for modern businesses. From websites to intelligent bots, we help you reduce manual labor and improve efficiency.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-500 hover:text-blue-600 dark:text-gray-400 dark:hover:text-blue-500">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-500 hover:text-blue-600 dark:text-gray-400 dark:hover:text-blue-500">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-500 hover:text-blue-600 dark:text-gray-400 dark:hover:text-blue-500">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-500 hover:text-blue-600 dark:text-gray-400 dark:hover:text-blue-500">
                <Linkedin className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Quick Links</h3>
            <ul className="space-y-3">
              <li>
                <Link to="/" className="text-gray-600 dark:text-gray-400 hover:text-blue-600 dark:hover:text-blue-500">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/services" className="text-gray-600 dark:text-gray-400 hover:text-blue-600 dark:hover:text-blue-500">
                  Services
                </Link>
              </li>
              <li>
                <Link to="/process" className="text-gray-600 dark:text-gray-400 hover:text-blue-600 dark:hover:text-blue-500">
                  Process
                </Link>
              </li>
              <li>
                <Link to="/contact" className="text-gray-600 dark:text-gray-400 hover:text-blue-600 dark:hover:text-blue-500">
                  Contact
                </Link>
              </li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Services</h3>
            <ul className="space-y-3">
              <li>
                <Link to="/services#websites" className="text-gray-600 dark:text-gray-400 hover:text-blue-600 dark:hover:text-blue-500">
                  Website Creation
                </Link>
              </li>
              <li>
                <Link to="/services#chatbots" className="text-gray-600 dark:text-gray-400 hover:text-blue-600 dark:hover:text-blue-500">
                  AI-powered Chatbots
                </Link>
              </li>
              <li>
                <Link to="/services#email" className="text-gray-600 dark:text-gray-400 hover:text-blue-600 dark:hover:text-blue-500">
                  Email Automation
                </Link>
              </li>
              <li>
                <Link to="/services#voice" className="text-gray-600 dark:text-gray-400 hover:text-blue-600 dark:hover:text-blue-500">
                  AI Voice Callers
                </Link>
              </li>
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Legal</h3>
            <ul className="space-y-3">
              <li>
                <Link to="/privacy" className="text-gray-600 dark:text-gray-400 hover:text-blue-600 dark:hover:text-blue-500">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link to="/terms" className="text-gray-600 dark:text-gray-400 hover:text-blue-600 dark:hover:text-blue-500">
                  Terms of Service
                </Link>
              </li>
              <li>
                <Link to="/cookies" className="text-gray-600 dark:text-gray-400 hover:text-blue-600 dark:hover:text-blue-500">
                  Cookie Policy
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-200 dark:border-gray-800 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-600 dark:text-gray-400 text-center md:text-left">
              © {currentYear} K.CORP Services. All rights reserved.
            </p>
            <div className="mt-4 md:mt-0">
              <p className="text-gray-500 dark:text-gray-500 text-sm">
                Designed with ❤️ for efficiency
              </p>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}