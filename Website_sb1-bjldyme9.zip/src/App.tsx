import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

// Layout components
import Header from './components/layout/Header';
import Footer from './components/layout/Footer';
import CookieConsent from './components/ui/CookieConsent';
import ChatWidget from './components/ui/ChatWidget';
import AnimatedBackground from './components/ui/AnimatedBackground';

// Pages
import HomePage from './pages/HomePage';
import ServicesPage from './pages/ServicesPage';
import ProcessPage from './pages/ProcessPage';
import ContactPage from './pages/ContactPage';
import FAQPage from './pages/FAQPage';
import PrivacyPage from './pages/PrivacyPage';
import TermsPage from './pages/TermsPage';
import CookiesPage from './pages/CookiesPage';

function App() {
  // Add custom font
  useEffect(() => {
    const link = document.createElement('link');
    link.href = 'https://fonts.cdnfonts.com/css/cofo-sans';
    link.rel = 'stylesheet';
    document.head.appendChild(link);

    // Add class to body for the font
    document.body.classList.add('font-sans');

    // Update document title
    document.title = 'K.CORP Services - Business Automation Solutions';

    return () => {
      document.head.removeChild(link);
    };
  }, []);

  return (
    <Router>
      <div className="flex flex-col min-h-screen relative">
        <AnimatedBackground />
        <Header />
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/services" element={<ServicesPage />} />
            <Route path="/process" element={<ProcessPage />} />
            <Route path="/contact" element={<ContactPage />} />
            <Route path="/faq" element={<FAQPage />} />
            <Route path="/privacy" element={<PrivacyPage />} />
            <Route path="/terms" element={<TermsPage />} />
            <Route path="/cookies" element={<CookiesPage />} />
          </Routes>
        </main>
        <Footer />
        <CookieConsent />
        <ChatWidget />
      </div>
    </Router>
  );
}

export default App;